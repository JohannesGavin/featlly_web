<?php $__env->startSection('title'); ?>
    Dashboard
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="flex gap-9">
        <a href="<?php echo e(route('admin.katalog.index')); ?>" class="bg-white rounded-2xl pl-2 px-9 py-6 flex items-center">
            <img src="<?php echo e(asset('/assets/img/order-admin.svg')); ?>" alt="">
            <div class="flex flex-col justify-between">
                <p class="text-[48px]"><?php echo e($katalog); ?></p>
                <p class="text-4xl">Katalog</p>
            </div>
        </a>
        <a href="<?php echo e(route('admin.pesanan')); ?>" class="bg-white rounded-2xl pl-2 px-9 py-6 flex items-center">
            <img src="<?php echo e(asset('/assets/img/catalog-admin.svg')); ?>" alt="">
            <div class="flex flex-col justify-between">
                <p class="text-[48px]"><?php echo e($order); ?></p>
                <p class="text-4xl">Pesanan</p>
            </div>
        </a>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\featlly_web\resources\views/admin-dashboard.blade.php ENDPATH**/ ?>