<?php $__env->startSection('content'); ?>
    <main class="py-14">
        <section class="container px-4 flex flex-col gap-5 items-center">
            <h1 class="text-center title-3 font-bold">Edit Katalog</h1>
            <form action="<?php echo e(route('admin.katalog.update', $katalog->id)); ?>" method="post"
                class="w-full max-w-[427px] flex flex-col gap-5" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <?php if($message = Session::get('error')): ?>
                    <div class="alert alert-danger alert-block mt-5 w-full p-2 text-gray-900 bg-red-200 rounded-md">
                        <?php echo e(message); ?>

                    </div>
                <?php endif; ?>
                <div class="form-group flex flex-col gap-3">
                    <label class="text-lg font-semibold" for="">Nama</label>
                    <input required value="<?php echo e($katalog->nama); ?>" class="input-field-2" type="text" name="nama"
                        id="nama" placeholder="Nama barang">
                    <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-sm text-red-800 text-opacity-80" role="alert">
                            <?php echo e($message); ?>

                        </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="form-group flex flex-col gap-3">
                    <label class="text-lg font-semibold" for="">Kategori</label>
                    <select required value="<?php echo e($katalog->kategori); ?>" class="input-field-2" name="kategori" id="kategori"
                        placeholder="kategori">
                        <option value="Atasan">Atasan</option>
                        <option value="Bawahan">Bawahan</option>
                        <option value="Aksesoris">Aksesoris</option>
                    </select>
                    <?php $__errorArgs = ['kategori'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-sm text-red-800 text-opacity-80" role="alert">
                            <?php echo e($message); ?>

                        </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="form-group flex flex-col gap-3">
                    <label class="text-lg font-semibold" for="">Detail</label>
                    <input required value="<?php echo e($katalog->detail); ?>" class="input-field-2" type="text" name="detail"
                        id="detail" placeholder="detail">
                    <?php $__errorArgs = ['detail'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-sm text-red-800 text-opacity-80" role="alert">
                            <?php echo e($message); ?>

                        </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="form-group flex flex-col gap-3">
                    <label class="text-lg font-semibold" for="">Harga</label>
                    <input required value="<?php echo e($katalog->harga); ?>" class="input-field-2" type="text" name="harga"
                        id="harga" placeholder="harga">
                    <?php $__errorArgs = ['harga'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-sm text-red-800 text-opacity-80" role="alert">
                            <?php echo e($message); ?>

                        </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="form-group flex flex-col gap-3">
                    <label class="text-lg font-semibold" for="">Harga Promo</label>
                    <input class="input-field-2" type="text" name="harga_promo" id="harga_promo"
                        placeholder="Harga promo" value="<?php echo e($katalog->harga_promo); ?>">
                    <?php $__errorArgs = ['harga_promo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-sm text-red-800 text-opacity-80" role="alert">
                            <?php echo e($message); ?>

                        </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="form-group flex flex-col gap-3">
                    <label class="text-lg font-semibold" for="">Gambar</label>
                    <input type="file" name="images[]" id="images" class="" multiple>
                    <?php $__errorArgs = ['images'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-sm text-red-800 text-opacity-80" role="alert">
                            <?php echo e($message); ?>

                        </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="flex flex-col mt-14 w-full gap-4">
                    <button type="submit" class="btn w-full items-center flex justify-center">Simpan perubahan</button>
                </div>
            </form>
        </section>

    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\featlly_web\resources\views/admin-edit-katalog.blade.php ENDPATH**/ ?>