<?php $__env->startSection('content'); ?>
    <main class="py-14">
        <section class="container px-4 flex flex-col gap-5 items-center">
            <h1 class="text-center title-3 font-bold">Pesanan anda telah diterima</h1>
            <h2 class="text-xl font-semibold mt-3">Order ID 2012345</h2>
            <h2 class="text-xl font-semibold">Total Pembayaran Rp 203.000</h2>
            <h3 class="text-neutral-400 text-center max-w-[500px]">Harap melakukan pembayaran sebelum 1 x 24 jam atau pesanan
                anda dibatalkan oleh sistem</h3>

            <a href="<?php echo e(route('home')); ?>" class="btn-outline w-full max-w-[440px]">Kembali</a>

            <form action="<?php echo e(route('confirm')); ?>" method="post" class="w-full max-w-[427px] flex flex-col gap-5 mt-10">
                <?php echo csrf_field(); ?>
                <div class="form-group flex flex-col gap-3">
                    <label class="text-lg font-semibold" for="">Order ID</label>
                    <input required class="input-field-2" type="text" name="name" id="name"
                        placeholder="Order id">
                </div>
                <div class="form-group flex flex-col gap-3">
                    <label class="text-lg font-semibold" for="">Tanggal Pembayaran</label>
                    <input required class="input-field-2" type="date" name="alamat" id="alamat" placeholder="Alamat">
                </div>
                <div class="form-group flex flex-col gap-3">
                    <label class="text-lg font-semibold" for="">Metode Pembayaran</label>
                    <input required class="input-field-2" type="text" name="provinsi" id="provinsi"
                        placeholder="OVO/Gopay/BCA">
                </div>
                <div class="form-group flex flex-col gap-3">
                    <label class="text-lg font-semibold" for="">Nama Pembayar</label>
                    <input required class="input-field-2" type="text" name="kabupaten" id="kabupaten"
                        placeholder="Nama Pembayar">
                </div>
                <div class="form-group flex flex-col gap-3">
                    <label class="text-lg font-semibold" for="">Gambar</label>
                    <input type="file" name="images[]" id="images" class="" multiple>
                    <?php $__errorArgs = ['images'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-sm text-red-800 text-opacity-80" role="alert">
                            <?php echo e($message); ?>

                        </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="flex flex-col mt-14 w-full gap-4">
                    <button type="submit" class="btn w-full items-center flex justify-center">Konfirmasi
                        pembayaran</button>
                </div>
            </form>
        </section>

    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\featlly_web\resources\views/confirm.blade.php ENDPATH**/ ?>