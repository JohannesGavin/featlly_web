<?php $__env->startSection('title'); ?>
    Katalog
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="mb-12">
        <a href="<?php echo e(route('admin.katalog.create')); ?>" class="btn btn-primary px-5">Tambah Katalog</a>
    </div>
    <table class="w-full text-sm text-left text-neutral-500 rounded-md overflow-hidden">
        <thead class="text-xs text-gray-700 uppercase bg-gray-50">
            <tr>
                <th scope="col" class="px-6 py-3">
                    No.
                </th>
                <th scope="col" class="px-6 py-3">
                    Nama
                </th>
                <th scope="col" class="px-6 py-3">
                    Kategori
                </th>
                <th scope="col" class="px-6 py-3">
                    Detail
                </th>
                <th scope="col" class="px-6 py-3">
                    Harga
                </th>
                <th scope="col" class="px-6 py-3">
                    Harga Promo
                </th>
                <th scope="col" class="px-6 py-3">
                    Gambar
                </th>
                <th scope="col" class="px-6 py-3">
                    Aksi
                </th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $katalog; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="bg-white">
                    <td scope="col" class="px-6 py-3">
                        <?php echo e($index + 1); ?>

                    </td>
                    <td scope="col" class="px-6 py-3">
                        <?php echo e($item->nama); ?>

                    </td>
                    <td scope="col" class="px-6 py-3">
                        <?php echo e($item->kategori); ?>

                    </td>
                    <td scope="col" class="px-6 py-3">
                        <?php echo e($item->detail); ?>

                    </td>
                    <td scope="col" class="px-6 py-3">
                        <?php echo e($item->harga); ?>

                    </td>
                    <td scope="col" class="px-6 py-3">
                        <?php echo e($item->harga_promo); ?>

                    </td>
                    <td scope="col" class="px-6 py-3">
                        <?php if(isset($item->gambar)): ?>
                            <?php $__currentLoopData = $item->gambar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gambar): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <img src="<?php echo e(asset('storage/images/' . $gambar)); ?>" width="40" height="40"
                                    class="object-cover border-[1px] border-slate-300" alt="">
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </td>
                    <td scope="col" class="px-6 py-3">
                        <div class="flex flex-col gap-2 items-center">
                            <a href="<?php echo e(route('admin.katalog.edit', $item->id)); ?>">Edit</a>
                            <form action="<?php echo e(route('admin.katalog.destroy', $item->id)); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit">
                                    <img src="<?php echo e(asset('assets/img/x-square.svg')); ?>" alt="">
                                </button>
                            </form>
                        </div>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\featlly_web\resources\views/admin-katalog.blade.php ENDPATH**/ ?>