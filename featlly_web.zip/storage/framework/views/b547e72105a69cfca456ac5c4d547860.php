<div class="carousel relative w-full md:hidden bg-white">
    <div class="carousel-inner relative overflow-hidden w-full">
        <?php $__currentLoopData = $katalog->gambar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <input class="carousel-open hidden" type="radio" id="carousel-<?php echo e($index); ?>" name="carousel" aria-hidden="true"
                hidden="" checked="<?php echo e($index === 0 ? 'checked' : ''); ?>">
            <div class="carousel-item absolute opacity-0" style="height:50vh;">
                <div class="block h-full w-full text-white text-5xl text-center">
                    <img src="<?php echo e(asset('storage/images/' . $image)); ?>"
                        class="bg-slate-100 h-full object-cover rounded-md mx-auto" alt="...">
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <ol class="carousel-indicators">
            <?php $__currentLoopData = $katalog->gambar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="inline-block mr-3">
                    <label for="carousel-<?php echo e($index); ?>"
                        class="carousel-bullet cursor-pointer block text-4xl text-white hover:text-primary-500">•</label>
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ol>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\featlly_web\resources\views/components/carousel.blade.php ENDPATH**/ ?>