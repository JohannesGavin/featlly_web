<?php $__env->startSection('content'); ?>
    <main class="py-14">
        <section class="container px-4 flex gap-5 flex-col md:flex-row">
            <?php echo $__env->make('components.carousel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <div class="flex-grow flex-1 gap-4 hidden md:grid grid-cols-2">
                <?php $__currentLoopData = $katalog->gambar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <img src="<?php echo e(asset('storage/images/' . $image)); ?>" class="bg-[#F4F3FC] rounded-2xl col-span-1"
                        alt="">
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="flex-1 flex-grow d">
                <p class="text-xs md:text-base text-primary-main"><?php echo e($katalog->kategori); ?></p>
                <h1 class="text-2xl md:headline font-bold"><?php echo e($katalog->nama); ?></h1>
                <p class="text-sm md:text-lg text-neutral-400"><?php echo e($katalog->detail); ?></p>

                <div class="flex items-center gap-3">
                    <?php if($katalog->harga_promo): ?>
                        <p class="line-through text-gray-400 mt-8 text-xl md:headline font-bold">
                            Rp<?php echo e(number_format($katalog->harga, 2, '.', ',')); ?>

                        </p>
                        <p class="mt-8 text-2xl md:headline font-bold">
                            Rp<?php echo e(number_format($katalog->harga_promo, 2, '.', ',')); ?>

                        </p>
                    <?php else: ?>
                        <p class="mt-8 text-2xl md:headline font-bold">
                            Rp<?php echo e(number_format($katalog->harga, 2, '.', ',')); ?>

                        </p>
                    <?php endif; ?>
                </div>

                <div class="flex flex-col gap-4 mt-7">
                    <a href="<?php echo e(route('cart')); ?>" class="btn-outline w-full lg:w-[440px]">Tambahkan ke Keranjang <img
                            src="<?php echo e(asset('assets/img/cart-blue.svg')); ?>" alt=""></a>
                    <a href="<?php echo e(route('wishlist')); ?>" class="btn-outline w-full lg:w-[440px]">Tambahkan Ke Wishlist <img
                            src="<?php echo e(asset('assets/img/love-blue.svg')); ?>" alt=""></a>
                </div>
            </div>
        </section>

        <section class="container px-4 grid grid-cols-6 mt-12 md:mt-20 gap-10 mb-12 md:mb-20">
            <h2 class="col-span-6 headline font-bold">Anda mungkin juga suka</h2>
            <?php $__currentLoopData = collect($katalogs)->take(3); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="<?php echo e(route('detail', ['id' => $item->id])); ?>"
                    class="card-produk self-center h-full flex flex-col col-span-3 md:col-span-2">
                    <img src="<?php echo e(asset('storage/images/' . $item->gambar[0])); ?>"
                        class="w-full md:w-full object-cover self-center h-32 md:h-[425px] bg-[#F4F3FC] rounded-2xl"
                        alt="">
                    <div class="flex flex-col gap-1 mt-2">
                        <p class="caption-2 text-neutral-300"><?php echo e($item->kategori); ?></p>
                        <p class="caption-2 font-medium"><?php echo e($item->nama); ?></p>

                        <div class="flex flex-col lg:flex-row lg:items-center gap-0 lg:gap-3">
                            <?php if($item->harga_promo): ?>
                                <p class="price line-through text-gray-400 md:mt-3 font-semibold footnote">
                                    Rp<?php echo e(number_format($item->harga, 2, '.', ',')); ?>

                                </p>
                                <p class="price md:mt-3 font-semibold footnote">
                                    Rp<?php echo e(number_format($item->harga_promo, 2, '.', ',')); ?>

                                </p>
                            <?php else: ?>
                                <p class="price md:mt-3 font-semibold footnote">
                                    Rp<?php echo e(number_format($item->harga, 2, '.', ',')); ?>

                                </p>
                            <?php endif; ?>
                        </div>
                    </div>
                </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </section>
    </main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\featlly_web\resources\views/detail.blade.php ENDPATH**/ ?>