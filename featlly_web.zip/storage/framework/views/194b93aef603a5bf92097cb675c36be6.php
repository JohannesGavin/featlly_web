<?php $__env->startSection('title'); ?>
    Pesanan
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <table class="w-full text-sm text-left text-neutral-500 rounded-md overflow-hidden">
        <thead class="text-xs text-gray-700 uppercase bg-gray-50">
            <tr>
                <th scope="col" class="px-6 py-3">
                    No.
                </th>
                <th scope="col" class="px-6 py-3">
                    Nama
                </th>
                <th scope="col" class="px-6 py-3">
                    Barang
                </th>
                <th scope="col" class="px-6 py-3">
                    Alamat
                </th>
                <th scope="col" class="px-6 py-3">
                    Jumlah
                </th>
                <th scope="col" class="px-6 py-3">
                    Total Harga
                </th>
                <th scope="col" class="px-6 py-3">
                    Keterangan
                </th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="bg-white">
                    <td scope="col" class="px-6 py-3">
                        <?php echo e($index + 1); ?>

                    </td>
                    <td scope="col" class="px-6 py-3">
                        <?php echo e($order->user->name); ?>

                    </td>
                    <td scope="col" class="px-6 py-3">
                        <?php echo e($order->barang); ?>

                    </td>
                    <td scope="col" class="px-6 py-3">
                        <?php echo e($order->user->alamat); ?>

                    </td>
                    <td scope="col" class="px-6 py-3">
                        <?php echo e($order->jumlah); ?>

                    </td>
                    <td scope="col" class="px-6 py-3">
                        <?php echo e($order->harga); ?>

                    </td>
                    <td scope="col" class="px-6 py-3">
                        <?php echo e($order->keterangan); ?>

                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\featlly_web\resources\views/admin-pesanan.blade.php ENDPATH**/ ?>