<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Featlly</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
    <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
    <?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css'); ?>
</head>

<body class="grid grid-cols-12">
    <section class="col-span-2">
        <div class="h-full px-10 py-8 flex flex-col fixed bg-white">
            <div class="logo">
                <a href="/">
                    <img src="<?php echo e(asset('assets/img/logo-featlly.svg')); ?>" alt=""></a>
            </div>

            <div class="flex flex-col gap-12 mt-10">
                <a class="<?php echo e(Route::current()->getName() == 'admin.dashboard' ? 'font-bold text-primary-500' : ''); ?>"
                    href="<?php echo e(route('admin.dashboard')); ?>">Dashboard</a>
                <a class="<?php echo e(Route::current()->getName() == 'admin.katalog.index' ? 'font-bold text-primary-500' : ''); ?>"
                    href="<?php echo e(route('admin.katalog.index')); ?>">Katalog</a>
                <a class="<?php echo e(Route::current()->getName() == 'admin.pesanan' ? 'font-bold text-primary-500' : ''); ?>"
                    href="<?php echo e(route('admin.pesanan')); ?>">Pesanan</a>
                <a class="<?php echo e(Route::current()->getName() == 'admin.keluar' ? 'font-bold text-primary-500' : ''); ?>"
                    href="<?php echo e(route('logout')); ?>">Keluar</a>
            </div>
        </div>
    </section>
    <section class="col-span-10 border-l-[1px] border-slate-100">
        <div class="px-14 py-6">
            <p class="text-[30px] font-medium"><?php echo $__env->yieldContent('title'); ?></p>
        </div>
        <div class="w-full bg-primary-0 bg-opacity-40 p-14 min-h-screen">
            <?php if(session('success')): ?>
                <div class="bg-green-100 p-3 rounded-md col-span-12 mb-5 text-green-800"><?php echo e(session('success')); ?></div>
            <?php endif; ?>
            <?php echo $__env->yieldContent('content'); ?>
        </div>
    </section>

    <script>
        AOS.init();
    </script>
</body>

</html>
<?php /**PATH C:\xampp\htdocs\featlly_web\resources\views/layouts/admin.blade.php ENDPATH**/ ?>